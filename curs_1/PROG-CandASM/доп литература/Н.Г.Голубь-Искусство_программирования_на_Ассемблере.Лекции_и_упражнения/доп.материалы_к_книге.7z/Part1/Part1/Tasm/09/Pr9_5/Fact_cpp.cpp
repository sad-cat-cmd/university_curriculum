/* ��������� �������� ���������� p = n! = 1*2*3*�*n.
                       ��������, ��� 0! = 1.
������������� �������� n ���� �� ����� (�� �������� ����������).
        			(c) Copyright 2001 by ������ �.�.
							��������� ����������
*/

#include <conio.h>
#include <fstream.h>
#include "convert.h"

int	       n;
unsigned int p;
const char* TITLE = TXT(" ��������� p=n!\n");
const char* INVITE = TXT("������� �������� n=[0..23]:  ");

extern "C"
  { void far proizv1(void);
    void far proizv2(void);
  }

int test( long int a) //!!!!!!!!!!!!!!!!!!!!!
  {	return((a>>15)+1)&~1;  };

template <class tint>
int input (tint&  n)
  { ifstream my_inp ("CON");
	 ofstream my_out ("CON");
	 my_inp >> n;
	 switch (my_inp.rdstate())
		{ case ios::goodbit:  return 0;
		  case ios::eofbit :  return 0;
		  case ios::failbit:
		  case ios::badbit :
			 my_out << "\n!!!!! ERROR !!!!!";
			 my_out << "\nLet's try once again.....\n";
		  return 1;
		}
}

unsigned long Factorial(int n)
  { unsigned long p=1;
    if (n == 0) return p;
	 for (int i=1;i<=n;i++)
	  	  p *= (unsigned long)i;
    return p;
  }

int main(void)
	 { char flag='y';
      long n1;
      int j=0;
	   do
		 { clrscr();
         cout << "\============= TEST #" << ++j << "==================\n";
			 do
				{ 	cout << TITLE;
					cout << INVITE;
				   while(input(n1));
			    }while ( n1<0 || n1>23 || test(n1));
           n=n1; // !!!!!!!!!!!!
           unsigned long ff = Factorial(n);
           unsigned int f = ff;
           // ��������� �������� ���������� �������� LONG INT
           if (f == ff)
             { cout<<"Result (C++):" << f <<endl;
               proizv1();
			      cout<<"Result1(ASM):" << p <<endl;
               p=0;
               proizv2();
			      cout<<"Result2(ASM):" << p <<endl;

              }
           else
             cout << "\n!!!! The Result " << ff << " has exceeded a VALID range!!!!\n";
           cout<<"\nWant to continue calculations? Or finish?   <y/CTRL+C>";
		     cin>>flag;
		   } while(flag=='y');
	   return 0;
 }
/*
============= TEST #1==================
 ????????? p=n!
??????? ???????? n:  0
Result(C++):1
Result(ASM):1

To processed / finish <y/CTRL+C>
============= TEST #2==================
 ????????? p=n!
??????? ???????? n:  3
Result(C++):6
Result(ASM):6

To processed / finish <y/CTRL+C>
============= TEST #3==================
 ????????? p=n!
??????? ???????? n:  7
Result(C++):5040
Result(ASM):5040

To processed / finish <y/CTRL+C>
============= TEST #4==================
 ????????? p=n!
??????? ???????? n:  8
Result(C++):40320
Result(ASM):40320

To processed / finish <y/CTRL+C>
============= TEST #10==================
 ????????? p=n!
??????? ???????? n:  9

!!!! The Result 362880 has exceeded a VALID range!!!!

To processed / finish <y/CTRL+C>
============= TEST #11==================
 ????????? p=n!
??????? ???????? n=[0..23]:  24
 ????????? p=n!
??????? ???????? n=[0..23]:  23

!!!! The Result 862453760 has exceeded a VALID range!!!!

To processed / finish <y/CTRL+C>
============= TEST #12==================
 ????????? p=n!
??????? ???????? n:  32

!!!! The Result 2147483648 has exceeded a VALID range!!!!

To processed / finish <y/CTRL+C>
============= TEST #13==================
 ????????? p=n!
??????? ???????? n:  33

!!!! The Result 2147483648 has exceeded a VALID range!!!!

To processed / finish <y/CTRL+C>
============= TEST #14==================
 ????????? p=n!
??????? ???????? n:  34
Result(C++):0
Result(ASM):0

To processed / finish <y/CTRL+C>
*/

