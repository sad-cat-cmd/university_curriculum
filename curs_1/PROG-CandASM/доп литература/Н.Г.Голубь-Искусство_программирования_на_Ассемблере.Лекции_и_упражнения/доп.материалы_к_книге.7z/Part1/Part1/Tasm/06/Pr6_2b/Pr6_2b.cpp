/* Pr6_2b.cpp               Borland C++ 5.02
              ������ !!!!!! Application.exe === > DOS (standard) !!!!!!
                              asm+cpp �����
         		(c) Copyright 1998-2001 by ������ �.�.
                         ���������� ������ 6.2b.
   							   ��������� ����������
� ������������ ��������� �� ������ "��������-��������������� ����������������"
                                 � "����������� � ���������������� ���"
                           x=a+b;
                      a,b,x : int;
                      a,b,x : char;
                      a,b,x : long int;
                      a,b,x : unsigned char (byte);
                      a,b,x : unsigned int (word);
               ���������� ���� �������� ��������.
*/

#include <iostream.h>
#include <conio.h>
#include <typeinfo.h>
#include "inputNum.h" // ���� ����� ����� �����

const char* InputA = " Input a: ";
const char* InputB = " Input b: ";
const char* ResultC = "\n\n Result      in C++ = ";
const char* ResultASM = "\n\n Result      in ASM = ";
const char* CONTINUE = "\n\n Press any key to continue...";

// ������� ������������ �������
extern "C"
{
 void addaI (void);
 void addaS (void);
 void addaL (void);
 void addaB (void);
 void addaW (void);
}

void title(void)
{
 cout << "\n\tCalculate expression:   x = a + b\n";
}

void title(long int a,long int b)
{
 cout <<"\n\t  "<< a << " + " << b << " = ";
}

void PressAnyKey()
{ cout <<  CONTINUE;
  getch();
}

char menu(void)
{
 cout<<"\n Select the type of arguments for calculation:\n\n"
     <<"\t 1 - Byte (1 byte without signum    - unsigned char)\n"
     <<"\t 2 - Char (1 byte with signum       - char )\n"
     <<"\t 3 - Word (2 bytes without signum   - unsigned int )\n"
     <<"\t 4 - Int  (2 bytes with signum      - int )\n"
     <<"\t 5 - long int  (4 bytes with signum - long int)\n"
     <<"\t 6 - Exit from this program...\n";
  return getch();
}

//--------------- ���������� ���������� - ���������� � ���������
long int a,b,x;
int aI,bI,xI;
byte aB,bB,xB;
char aS,bS,xS;
word aW,bW,xW;
//---------------------------------------------------------------

// ����������������� ������� ���������� x=a+b
template <class Type>
int calculate(Type a,Type b, Type& Result)
{ //float x = (float)a+b;  - ������� �������� �� ������!!!!!!!!!!!
  long double x = (long double)a+b;
  Result  = a+b;
  if (x != Result) // �������� ����������� ���������
   { cout << "\n!!!!!!! Result " << x << " is out range " << typeid(a).name();
     return 0;  // Error Range!
    }
  return 1;  // Ok!
}

void ProcByte()
{
 cout<<"\n Type of arguments  BYTE (0..255)\n\n";
 while (input (InputA,aB));
 while (input (InputB,bB));
 title(aB,bB);
 if (calculate(aB,bB,xB))
  { cout << ResultC << (int)xB;
    xB=0; addaB();
    cout << ResultASM << (int)xB;
   }
}

void ProcChar()
{
 cout<<"\n Type of arguments CHAR (-128..127) \n\n";
 while (input (InputA,aS));
 while (input (InputB,bS));
 title(aS,bS);
 if (calculate(aS,bS,xS))
  { cout << ResultC << (int)xS;
    xS=0; addaS();
    cout << ResultASM << (int)xS;
   }
}

void ProcWord()
{
 cout<<"\n Type of arguments WORD (0..65535)\n\n";
 while (input (InputA,aW));
 while (input (InputB,bW));
 title(aW,bW);
 if (calculate(aW,bW,xW))
  { cout <<  ResultC << xW;
    xW=0; addaW();
    cout << ResultASM << xW;
   }
}

void ProcInt()
{
 cout<<"\n Type of arguments INT (-32768..32767)\n\n";
 while (input (InputA,aI));
 while (input (InputB,bI));
 title(aI,bI);
 if (calculate(aI,bI,xI))
  { cout << ResultC << xI;
    xI=0; addaI();
    cout << ResultASM << xI;
   }
}

void ProcLongInt()
{
 cout<<"\n Type of arguments  LONG INT (-2147483648..2147483647)\n\n";
 while (input (InputA,a));
 while (input (InputB,b));
 title(a,b);
 if (calculate(a,b,x))
  { cout << ResultC << x;
    x=0; addaL();
    cout << ResultASM << x;
   }
}

int main(void)
{
 int t=0;
 char point;
 do{
 clrscr();
 title();
 point = menu();
 switch(point)
 {
  case '1':ProcByte();break;
  case '2':ProcChar();break;
  case '3':ProcWord();break;
  case '4':ProcInt(); break;
  case '5':ProcLongInt(); break;
  case '6': return 0;
 }
 cout << "\n====================== test #" << ++t << " ========================\n";
 PressAnyKey();
 }while (point != '6');
}
/*
        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments  BYTE (0..255)

 Input a: 222
 Input b: 111

          222 + 111 =
!!!!!!! Result 333 is out range unsigned char
====================== test #1 ========================

 Press any key to continue...
        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments  BYTE (0..255)

 Input a: -11
        Error! Incorrect range for type unsigned char
 Input a: 22
 Input b: 33de

          22 + 33 =

 Result      in C++ = 55

 Result      in ASM = 55
 ====================== test #2 ========================

 Press any key to continue...

        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments CHAR (-128..127)

 Input a: -22
 Input b: -222
        Error! Incorrect range for type char
 Input b: -120

          -22 + -120 =
!!!!!!! Result -142 is out range char
====================== test #3 ========================

 Press any key to continue...
        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments CHAR (-128..127)

 Input a: -128
 Input b: 127

          -128 + 127 =

 Result      in C++ = -1

 Result      in ASM = -1
====================== test #4 ========================

 Press any key to continue...
        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments WORD (0..65535)

 Input a: 44444
 Input b: -4
        Error! Incorrect range for type unsigned int
 Input b: -11111
        Error! Incorrect range for type unsigned int
 Input b: 11111

          44444 + 11111 =

 Result      in C++ = 55555

 Result      in ASM = 55555
====================== test #5 ========================

 Press any key to continue...
        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments INT (-32768..32767)

 Input a: -423
 Input b: 4355

          -423 + 4355 =

 Result      in C++ = 3932

 Result      in ASM = 3932
====================== test #6 ========================

 Press any key to continue...
        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments  LONG INT (-2147483648..2147483647)

 Input a: 2222222
 Input b: 111111

          2222222 + 111111 =

 Result      in C++ = 2333333

 Result      in ASM = 2333333
====================== test #7 ========================

 Press any key to continue...

        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments  LONG INT (-2147483648..2147483647)

 Input a: 1111111111
 Input b: 1111111111

          1111111168 + 1111111168 =           ??????????????
!!!!!!! Result 2.22222e+09 is out range long
====================== test #8 ========================

 Press any key to continue...

        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments  LONG INT (-2147483648..2147483647)

 Input a: 1111111111111
        Error! Incorrect range for type long
 Input a: 11111111
 Input b: 22222222

          11111111 + 22222222 =
!!!!!!! Result 3.33333e+07 is out range long  ??????????????
====================== test #9 ========================

 Press any key to continue...
-------------------------------------------------------------------------------

 -------------- ����� ��������� long double x; -----------------------

        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments  LONG INT (-2147483648..2147483647)

 Input a: 1111111111
 Input b: 1111111111

          1111111111 + 1111111111 =
!!!!!!! Result 2.22222e+09 is out range long
====================== test #1 ========================

 Press any key to continue...
        Calculate expression:   x = a + b

 Select the type of arguments for calculation:

         1 - Byte (1 byte without signum    - unsigned char)
         2 - Char (1 byte with signum       - char )
         3 - Word (2 bytes without signum   - unsigned int )
         4 - Int  (2 bytes with signum      - int )
         5 - long int  (4 bytes with signum - long int)
         6 - Exit from this program...

 Type of arguments  LONG INT (-2147483648..2147483647)

 Input a: 11111111
 Input b: 22222222

          11111111 + 22222222 =

 Result      in C++ = 33333333

 Result      in ASM = 33333333
====================== test #2 ========================

 Press any key to continue...

*/